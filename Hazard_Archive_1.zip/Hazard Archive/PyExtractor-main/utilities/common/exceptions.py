class FileFormatException(Exception):
    """Raised when the binary is not exe"""
    pass
