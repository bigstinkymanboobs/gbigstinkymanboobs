---
name: Bug Report
about: Report a bug to the developers.
title: Hazard Nuker [BUG]
labels: bug
assignees: [DeKrypted,Rdimo]

---

*Please provide the following info:*

**Description:**

What's expected to happen:


What actually happens:


**How to recreate this bug:**


**(Optional but preferred) Screenshots/Video:**

