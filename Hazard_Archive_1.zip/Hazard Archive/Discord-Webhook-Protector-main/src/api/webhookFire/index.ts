import webhookPayload from './webhookPayload.js';
import webhookFiles from './webhookFiles.js';

export { webhookPayload, webhookFiles };
